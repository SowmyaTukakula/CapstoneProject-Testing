document.getElementById('loginBtn').addEventListener('click', function() {
    chrome.tabs.create({ url: 'Capstonetesting/frontend/register.html' });
  });
