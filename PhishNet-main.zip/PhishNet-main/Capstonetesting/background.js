chrome.runtime.onInstalled.addListener(() => {
  console.log("PhishNet extension installed!");
});
