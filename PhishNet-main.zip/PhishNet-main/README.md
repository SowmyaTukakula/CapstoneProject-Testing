# PhishNet
For now, in order to connect it and add stuff unto it. You need to load in=t into your google extension.
I have created a new gmail account solely for testing it. If you would like it, lmk
After loading it, you go into the google cloud console to create an ID for yourself,
To create the ID, you have to copy the ID from the extension you are loading on into the google cloud console. 
Testing from there is done through the cmd line. 
Install all the requirements (requirements are mnot updated, so if anyone wants to update them, you are welcome to)
and run the script in the 'backend directory'
The code is still a mess, as I am still training the model.
Goodluck!!!
